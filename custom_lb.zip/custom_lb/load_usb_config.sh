#!/bin/bash

mount -t configfs none /config
mkdir /config/usb_gadget/g1
echo 0x00aa > /config/usb_gadget/g1/idVendor
echo 0x00bb > /config/usb_gadget/g1/idProduct
echo 0x0200 > /config/usb_gadget/g1/bcdUSB
mkdir /config/usb_gadget/g1/strings/0x409
echo IGN > /config/usb_gadget/g1/strings/0x409/manufacturer
echo IGN_IPU > /config/usb_gadget/g1/strings/0x409/product
echo 012345678ABCDEF>/config/usb_gadget/g1/strings/0x409/serialnumber
mkdir /config/usb_gadget/g1/configs/b.1
mkdir /config/usb_gadget/g1/functions/Customlb.name
cat /config/usb_gadget/g1/functions/Customlb.name/qlen
echo 4096 > /config/usb_gadget/g1/functions/Customlb.name/bulk_buflen
ln -s /config/usb_gadget/g1/functions/Customlb.name /config/usb_gadget/g1/configs/b.1/f1
echo 3550000.xudc > /config/usb_gadget/g1/UDC

echo "finished configuration"
